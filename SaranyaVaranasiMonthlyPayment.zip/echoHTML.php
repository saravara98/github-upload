<?php

function echoHead($cssFile)
{
	echo '
	<!DOCTYPE html>
<html>
<head>
	<title>Monthly Payment Calculator</title>
	<link rel="stylesheet" type="text/css" href=' .$cssFile. '">
	</head>
	' ;
}

function echoHeader($title)
{
	echo '<body>';
	echo' <h1> '.$title.'</h1>';
	echo'';
}

function echofooter()
{
	echo' <h6><a href="mailto:coffee@gmail.com" >Contact </a> for more information </h6>';
}
?>